# either bundle adjustment or pose graph optimization
from queue import Queue
from frameState import FrameState

class PoseGraphOptimizer:
    def __init__(self, frame_queue: Queue[FrameState]):
        pass

    def optimize():
        pass
