# place to store all parameters

class params():

    def __init__(self):
        self.params1 = 69
        self.params2 = 'Max likes Italiens'
